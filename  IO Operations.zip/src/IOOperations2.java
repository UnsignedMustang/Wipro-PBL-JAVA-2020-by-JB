import java.lang.*;
import java.util.*;
import java.io.*;
public class IOOperations2 {
	public static void main(String[] args)throws Exception {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the file name:-");
		String input = reader.readLine();
		System.out.println("Enter the output file name");
		String output = reader.readLine();
		
		File filein = new File("src/"+input);
		File fileout = new File("src/"+output);
		
		BufferedReader br = new BufferedReader(new FileReader(filein));
		BufferedWriter bw = new BufferedWriter(new FileWriter(fileout));
		
		String temp;
		while((temp=br.readLine())!=null) {
			bw.write(temp);
			bw.flush();
		}
		System.out.println("Copy complete!!!");
	}
}
