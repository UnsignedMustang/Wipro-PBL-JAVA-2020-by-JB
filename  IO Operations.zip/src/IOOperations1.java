import java.util.*;
import java.io.*;
import java.lang.*;
public class IOOperations1 {

	public static void main(String[] args) throws Exception {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the name of the file:-");
		String file_name = reader.readLine();
		System.out.println("Enter the character to be found:-");
		char char_find = reader.readLine().charAt(0);
		File file = new File("src/"+file_name);
		
		BufferedReader br = new BufferedReader(new FileReader(file));
		int count=0;
		String test;
		while((test=br.readLine())!=null) {
			for(int i=0;i<test.length();i++) {
				if(char_find==Character.toLowerCase(test.charAt(i)) || (char_find==Character.toUpperCase(test.charAt(i))))
					count++;
			}
		}
		System.out.println(count);
	}

}
